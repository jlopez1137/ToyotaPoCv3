# TMHNA Enterprise Portal - Proof of Concept

## Overview

This is a static Proof of Concept for the TMHNA Enterprise Portal - an internal enterprise tool that demonstrates how Toyota Material Handling North America could unify Toyota, Raymond, and THD operations through a shared digital backbone while preserving brand autonomy.

**This is NOT a marketing website or slide deck.** This PoC represents what TMHNA could actually deploy internally as a production-grade portal with navigation, role-based views, dashboards, and operational surfaces.

## What This PoC Represents

This portal demonstrates:

- **Enterprise Alignment**: Governance surfaces, standards library, decision paths, and ownership frameworks
- **Unified Financial Intelligence**: Enterprise dashboards, brand views, profitability lens, and drill-down capabilities
- **Operations & Fleet**: Connected fleet insights, automation status, and telematics event streams
- **Communications Hub**: Enterprise feed with categories, targeted audiences, and cross-functional alerts
- **Brand Autonomy**: Shared backbone concept with independent execution preserved
- **Enablement Roadmap**: Product-style delivery timeline (not phase slides)

## Portal Pages

1. **Portal Home** (`index.html`) - Executive overview dashboard with KPIs, alerts, and strategic alignment status
2. **Financial Intelligence** (`finance.html`) - Enterprise P&L, profitability lens, brand comparison, and unified definitions
3. **Operations & Fleet** (`operations.html`) - Fleet insights, automation status, and telematics event stream
4. **Communications Hub** (`comms.html`) - Enterprise feed with categories (Leadership, Plant, Safety, HR, IT, Operations)
5. **Enterprise Governance** (`governance.html`) - Decision paths, ownership, standards library, and meeting cadence
6. **Brands & Business Units** (`brands.html`) - Brand overviews and shared backbone concept
7. **Enablement Roadmap** (`roadmap.html`) - Product-style roadmap with Now/Next/Later lanes

## Features

### Navigation
- Top bar with TMHNA logo, global search, notifications, and profile dropdown
- Left sidebar navigation to all portal pages
- Role switcher dropdown (Executive, Finance Leader, Plant Leader, Dealer Manager)
- Brand filter dropdown (All TMHNA, Toyota, Raymond, THD)

### Interactive Elements
- **Role Switching**: Changes visible modules and default filters (simulated RBAC)
- **Brand Filtering**: Updates KPI values and labels based on selected brand
- **Tabs**: Profitability lens tabs, communications category tabs
- **Drawers**: Expandable sections for definitions and controls
- **Search**: Local filtering of visible content (static)

### UI Components
- Professional design system with consistent spacing and typography
- KPI cards with values, labels, and change indicators
- Tables for data presentation
- Feed items with categories, timestamps, and tags
- Badges and pills for status and categorization
- Alerts and notifications
- Roadmap lanes for delivery timeline

## Viewing Locally

This is a purely static website with no build steps or dependencies.

**Option 1: Direct File Access**
1. Navigate to the `docs` folder
2. Open `index.html` in any modern web browser

**Option 2: Local HTTP Server** (Recommended)
```bash
cd docs
python -m http.server 8000
```
Then open `http://localhost:8000` in your browser.

## Deployment to GitHub Pages

To deploy this PoC to GitHub Pages:

1. Push this repository to GitHub under the account `jlopez1137` with repository name `ToyotaPoCv3`
2. Go to the repository Settings
3. Navigate to Pages (under Code and automation)
4. Under "Source", select "GitHub Actions" (or "Deploy from a branch" → `/docs`)
5. If using GitHub Actions, ensure the workflow file (`.github/workflows/pages.yml`) exists
6. The site will be available at: `https://jlopez1137.github.io/ToyotaPoCv3/`

## Technical Details

### File Structure

```
ToyotaPoCv3/
├── docs/
│   ├── index.html          # Portal Home
│   ├── finance.html        # Financial Intelligence
│   ├── operations.html      # Operations & Fleet
│   ├── comms.html          # Communications Hub
│   ├── governance.html     # Enterprise Governance
│   ├── brands.html         # Brands & Business Units
│   ├── roadmap.html        # Enablement Roadmap
│   ├── styles.css          # Design system and components
│   ├── app.js              # Shared JavaScript (navigation, role switching, brand filtering)
│   └── .nojekyll           # Disable Jekyll processing
├── .github/
│   └── workflows/
│       └── pages.yml       # GitHub Actions deployment workflow
└── README.md               # This file
```

### Technologies Used

- **HTML5**: Semantic markup, multi-page structure
- **CSS3**: Modern styling with CSS Grid and Flexbox, professional design system
- **Vanilla JavaScript**: UI interactions only (tabs, role switching, brand filtering, search)
- **No frameworks**: No React, Vue, Angular, or any other framework
- **No build tools**: No npm, webpack, or bundlers
- **No dependencies**: Everything is self-contained

### Design Philosophy

- **Toyota-inspired**: Clean, minimal, executive aesthetic
- **Portal UI**: Feels like a real enterprise product, not a marketing site
- **Professional**: Credible for CIO/CFO/COO demos
- **Restrained**: White/light backgrounds, strong typography, subtle Toyota-red accents
- **Operational**: Neutral, operational wording throughout

## Important Disclaimer

**This is a static demonstration.**

- All numbers, metrics, and data points are hardcoded sample values
- No real-time data or live integrations
- No operational functionality
- UI interactions are simulated for demonstration purposes only
- Role switching and brand filtering update UI state only (no backend)
- This PoC is designed to facilitate discussion with senior leadership and stakeholders

## Browser Support

Works in all modern browsers:
- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)
- Mobile browsers (responsive design)

---

**Note**: This Proof of Concept is a visual representation intended for executive presentation and stakeholder discussion. It does not represent a functional application or connect to any real systems or data sources.
